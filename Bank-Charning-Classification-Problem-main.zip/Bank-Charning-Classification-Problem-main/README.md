# Bank-Charning-Classification-Problem

Charn is a common data science problem in retail industries, banks to telecom to supermarkets. Applied a few classification models to predict charn clients.
